#!/bin/bash
cd /home/superdarn/realtimedisplay/

declare -A radars
declare -A radar
radar_codes=()

radar_name="sas"
radar_codes+=($radar_name)
radar[addr]=10.64.104.134
radar[in_port]=9696
radar[out_port]=5000
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

radar_name="rkn"
radar_codes+=($radar_name)
radar[addr]=127.0.0.1
radar[in_port]=53596
radar[out_port]=5001
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

radar_name=pgr
radar_codes+=($radar_name)
radar[addr]=127.0.0.1
radar[in_port]=51596
radar[out_port]=5002
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

radar_name=cly
radar_codes+=($radar_name)
radar[addr]=127.0.0.1
radar[in_port]=52596
radar[out_port]=5003
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

radar_name=inv
radar_codes+=($radar_name)
radar[addr]=127.0.0.1
radar[in_port]=54596
radar[out_port]=5004
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

radar_name=bks
radar_codes+=($radar_name)
radar[addr]=sd-software.ece.vt.edu
radar[in_port]=1045
radar[out_port]=5005
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

radar_name=fhe
radar_codes+=($radar_name)
radar[addr]=sd-software.ece.vt.edu
radar[in_port]=1050
radar[out_port]=5006
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

radar_name=fhw
radar_codes+=($radar_name)
radar[addr]=sd-software.ece.vt.edu
radar[in_port]=1051
radar[out_port]=5007
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

radar_name=kap
radar_codes+=($radar_name)
radar[addr]=sd-software.ece.vt.edu
radar[in_port]=1048
radar[out_port]=5008
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

radar_name=gbr
radar_codes+=($radar_name)
radar[addr]=sd-software.ece.vt.edu
radar[in_port]=1049
radar[out_port]=5009
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

radar_name=cve
radar_codes+=($radar_name)
radar[addr]=sdnet.thayer.dartmouth.edu
radar[in_port]=1051
radar[out_port]=5010
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

radar_name=cvw
radar_codes+=($radar_name)
radar[addr]=sdnet.thayer.dartmouth.edu
radar[in_port]=1052
radar[out_port]=5011
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

radar_name=mcm
radar_codes+=($radar_name)
radar[addr]=superdarn.met.psu.edu
radar[in_port]=6024
radar[out_port]=5012
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

radar_name=kod
radar_codes+=($radar_name)
radar[addr]=superdarn.met.psu.edu
radar[in_port]=6023
radar[out_port]=5013
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

radar_name=hok
radar_codes+=($radar_name)
radar[addr]=133.47.144.15
radar[in_port]=10021
radar[out_port]=5014
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

radar_name=hkw
radar_codes+=($radar_name)
radar[addr]=133.47.144.15
radar[in_port]=10056
radar[out_port]=5015
for key in "${!radar[@]}"; do
  radars[$radar_name,$key]=${radar[$key]}
done

borealis_radars=(sas rkn pgr cly inv) 
for i in "${radar_codes[@]}"
do
    if [[ " ${borealis_radars[*]} " == *"$i"* ]];
    then
        screen -d -m -S $i python3 realtimedisplay_borealis.py ${radars[$i,addr]} ${radars[$i,in_port]} ${radars[$i,out_port]}
    else
        screen -d -m -S $i python3 realtimedisplay.py ${radars[$i,addr]} ${radars[$i,in_port]} ${radars[$i,out_port]}
    fi
done

