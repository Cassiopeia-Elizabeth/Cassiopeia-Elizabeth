#!/bin/bash
#cd websockets/websockify
start_port=5000
web_address=chapman.usask.ca
for i in {0..16}
do
     $((start_port + 100 + i)) ./websockify.py -v  $((start_port + 100 + i)) $web_address:$((start_port + i)) >>/dev/null &

done
