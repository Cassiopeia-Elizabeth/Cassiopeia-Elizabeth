#!/usr/bin/env python

import websockify

websockify.websocketproxy.websockify_init()
